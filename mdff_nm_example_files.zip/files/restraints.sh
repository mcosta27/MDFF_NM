vmd -dispdev text -e restraints.tcl > out.restraints
